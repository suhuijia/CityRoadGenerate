__all__=['main', 'petrasch_aufteilen', 'construct_polygons', 'grundstuecke', 'Poly', 'weg_von_der_strasse']
