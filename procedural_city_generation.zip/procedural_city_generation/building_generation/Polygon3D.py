class Polygon3D(object):
    def __init__(self, verts, faces, texture):
        self.verts=verts
        self.faces=faces
        self.texture=texture
